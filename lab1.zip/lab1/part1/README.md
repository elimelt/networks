Group Members:
Elijah Melton - elimelt
Dhreeti Rathore - dhreetir
Nathan Khuat - nkhuat

## The sequence of server secrets that were received by your client program:

- secretA: 60
- secretB: 30
- secretC: 241
- secretD: 11

## Instructions on how to compile and run your code

1. Make sure you python 3 installed
2. Set `SERVER_HOST` inside of client.py to the server's hostname or IP address
3. Run `python3 client.py` to start the client